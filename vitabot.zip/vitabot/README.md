# 🌿 VitaBot – AI Wellness Asistent

## Navodila za postavitev

### 1. GitHub
1. Pojdi na github.com → New repository → ime: `vitabot`
2. Uploadaj vse datoteke iz te mape

### 2. Backend na Render.com
1. Pojdi na render.com → New → Web Service
2. Poveži GitHub repozitorij
3. Nastavitve:
   - **Root Directory:** `backend`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. Environment Variables → Add:
   - Key: `ANTHROPIC_API_KEY`
   - Value: tvoj API ključ (iz console.anthropic.com)
5. Klikni **Deploy**
6. Kopiraj URL (npr. `https://vitabot-backend.onrender.com`)

### 3. Frontend na Render.com
1. New → Static Site
2. Poveži isti GitHub repozitorij
3. Nastavitve:
   - **Root Directory:** `frontend/public`
   - **Publish Directory:** `.`
4. Pred deployem odpri `frontend/public/index.html`
   - Poišči vrstico: `const BACKEND_URL = "https://vitabot-backend.onrender.com";`
   - Zamenjaj z URL-jem tvojega backenda
5. Klikni **Deploy**

### Končano! 🎉
Tvoj VitaBot je živ na internetu in ga lahko prodajaš podjetjem.

---
**Cena gostovanja:** 0€ (Render brezplačni plan)
**API stroški:** ~0.01€ na pogovor
