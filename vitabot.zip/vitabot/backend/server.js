const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const SYSTEM_PROMPT = `Si VitaBot, profesionalni AI wellness asistent za podjetja. Pomagaš zaposlenim z nasveti o:
- Telesnem zdravju (gibanje, vadba, drža, bolečine)
- Prehrani in energiji
- Mentalnem zdravju (stres, koncentracija, spanje)
- Wellness rutinah pri delu

Odgovarjaj v slovenščini, prijazno in profesionalno. Odgovori naj bodo praktični in konkretni. Uporabljaj emoji. Za resne zdravstvene težave priporoči zdravnika.`;

app.post("/chat", async (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Manjkajo sporočila" });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      return res.status(500).json({ error: "API napaka", detail: err });
    }

    const data = await response.json();
    const reply = data.content?.[0]?.text || "Prišlo je do napake.";
    res.json({ reply });
  } catch (e) {
    res.status(500).json({ error: "Strežniška napaka: " + e.message });
  }
});

app.get("/health", (_, res) => res.json({ status: "ok" }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`VitaBot backend teče na portu ${PORT}`));
